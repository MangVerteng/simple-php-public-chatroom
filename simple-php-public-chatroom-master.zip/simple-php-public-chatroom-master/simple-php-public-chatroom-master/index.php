<?php 
	session_start();

	// connect to database
	$db = mysqli_connect("localhost", "root", "", "SHOUTIT");

	if (isset($_POST['login_btn'])) {

		$username = mysql_real_escape_string($_POST['username']);
		$password = mysql_real_escape_string($_POST['password']);
		$password = md5($password); // remember we hashed password before storing last time
		$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
		$result = mysqli_query($db, $sql);
		
		
		

		if (mysqli_num_rows($result) == 1) {
			$_SESSION['message'] = "You are now logged in";
			$_SESSION['username'] = $username;
			header("location: main.php"); //redirect to home page
		}else{
			$_SESSION['message'] = "Username/password combination incorrect";
		}
		
	$_SESSION['username'] = $username;	
	}
	
	

?>



<!DOCTYPE html>
<html>
<head>
	<title>Register, login and logout user php mysql</title>
	<link rel="stylesheet" type="text/css" href="css/new.css">
</head>
<body>

<br>
<br>
<br>
<br>
<br>
<?php
	if (isset($_SESSION['message'])) {
		echo "<div id='error_msg'>".$_SESSION['message']."</div>";
		unset($_SESSION['message']);
	}

?>



<form method="post" action="index.php">
<div class="header"> 
	<h1><img src="icon.png" style="width:70px;height:60px;"> &nbsp; GROUP CHATBOX</h1>

</div>
	<table align="center">
	&nbsp;
		<tr>
			<td>Username:</td>
			<td><input type="text" name="username" class="textInput"></td>
		</tr>

		<tr>
			<td>Password:</td>
			<td><input type="password" name="password" class="textInput"></td>
		</tr>
	</table>
	<br>
	<center>
	<a href="register.php">Create you account</a>
	<input type="submit" name="login_btn" value="Login">
	</center>
	<br>
</form>




</body>
</html>